My code is in C++. I did all of it on UCI's OpenLab, so I would recommend having that open (or something similar). I don't have an executable, just the cpp file, so you will need to build it like a normal cpp file. You don't have to spell any commands. I have it set to open the input.txt file, write to output.txt, and close on its own. I've tested this already with input.txt and it works so please let me know if you have any trouble. I can do a demonstration. Just make sure that input.txt is in the same folder as the cpp/hpp files. 

Aside from this file, the zip file inlcudes:
	~ project1.hpp
		* This is the header file for the main program. I included all of my declarations in here.
	~ project1.cpp
		* This is the main file (the one to run). It includes implementations of all the functions I declared in the hpp.

Outside of the zip file is my output.txt which is created when I run the program. 
